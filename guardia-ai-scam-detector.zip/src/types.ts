/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Verdict {
  SAFE = "Safe",
  SUSPICIOUS = "Suspicious",
  SCAM = "Scam",
}

export enum RiskLevel {
  LOW = "Low",
  MEDIUM = "Medium",
  HIGH = "High",
}

export interface AnalysisResult {
  verdict: Verdict;
  scamScore: number;
  riskLevel: RiskLevel;
  type: string;
  reason: string;
  highlightedWords: string[];
  redFlags: string[];
  advice: string;
}
