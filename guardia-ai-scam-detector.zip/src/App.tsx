/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Shield, ShieldAlert, ShieldCheck, Search, Trash2, AlertCircle } from "lucide-react";
import { analyzeText } from "./services/geminiService";
import { AnalysisResult, Verdict } from "./types";

export default function App() {
  const [inputText, setInputText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    if (!inputText.trim()) return;
    
    setIsAnalyzing(true);
    setError(null);
    setResult(null);

    try {
      const data = await analyzeText(inputText);
      setResult(data);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleClear = () => {
    setInputText("");
    setResult(null);
    setError(null);
  };

  const examples = [
    { label: "UPI Scam", text: "Dear Customer, you have won a cash prize of ₹10,000 from KBC. To claim your prize, please scan this QR code and enter your UPI PIN. Urgent action required or prize will expire." },
    { label: "Electricity Bill", text: "Urgent Notification: Your Electricity connection will be disconnected tonight at 9:30 PM because your previous month's bill was not updated. Please contact our officer at 88234-XXXXX immediately." },
    { label: "Job Fraud", text: "Work from Home Opportunity! Earn ₹3000-5000 daily by simply liking YouTube videos. No investment required. Contact our HR on Telegram @EarnMoneyInd for details." },
    { label: "KYC Update", text: "Your SBI account KYC has expired. App will be blocked. Please update your KYC now by clicking here: http://sbi-kyc-verify.online/update" }
  ];

  return (
    <div className="min-h-screen p-4 sm:p-8 flex flex-col max-w-6xl mx-auto space-y-8">
      {/* Header Section */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-end border-b border-slate-800 pb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className={`w-3 h-3 rounded-full shadow-[0_0_8px_currentColor] ${
              result?.verdict === Verdict.SCAM ? "bg-red-500 text-red-500" :
              result?.verdict === Verdict.SUSPICIOUS ? "bg-amber-500 text-amber-500" :
              "bg-emerald-500 text-emerald-500"
            }`}></div>
            <h1 className="text-2xl font-bold tracking-tight text-white uppercase flex items-center gap-2">
              ScamGuard <span className="text-red-500">AI</span>
            </h1>
          </div>
          <p className="label-tech">India Fraud Detection Protocol v4.02</p>
        </div>
        <div className="flex gap-8 mt-4 sm:mt-0">
          <div>
            <p className="label-tech opacity-50">System Status</p>
            <p className={`text-sm font-mono flex items-center gap-2 ${
              isAnalyzing ? "text-amber-400" : "text-emerald-400"
            }`}>
              {isAnalyzing ? "ANALYZING..." : "READY"}
            </p>
          </div>
          <div>
            <p className="label-tech opacity-50">Threat Level</p>
            <p className={`text-sm font-mono ${
              result?.riskLevel === "High" ? "text-red-400" :
              result?.riskLevel === "Medium" ? "text-amber-400" :
              "text-emerald-400"
            }`}>
              {result?.riskLevel || "NONE"}
            </p>
          </div>
        </div>
      </header>

      {/* Main Content Grid */}
      <main className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-8">
        
        {/* Left: Input Selection Area */}
        <div className="md:col-span-4 flex flex-col gap-6">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="h-px flex-1 bg-slate-800"></div>
              <span className="label-tech">Input Terminal</span>
            </div>

            <div className="card-geo p-4 relative group">
              <textarea
                className="w-full bg-slate-900 border-none focus:ring-0 text-sm font-mono text-slate-300 placeholder-slate-600 resize-none min-h-[200px]"
                placeholder="Paste suspicious content here..."
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={isAnalyzing}
              />
              <div className="mt-4 flex flex-col gap-3">
                <button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || !inputText.trim()}
                  className={`w-full py-3 px-6 transition-all duration-300 font-black text-xs uppercase tracking-widest border border-transparent ${
                    isAnalyzing 
                      ? "bg-slate-800 text-slate-500 cursor-not-allowed border-slate-700" 
                      : inputText.trim() 
                        ? "bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-900/20" 
                        : "bg-slate-800 text-slate-600 cursor-not-allowed border-slate-700"
                  }`}
                >
                  {isAnalyzing ? "DECODING..." : "START SCAN"}
                </button>
                <button 
                  onClick={handleClear}
                  className="btn-geo w-full"
                >
                  Clear Buffer
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <p className="label-tech opacity-50">Quick Check Library</p>
              <div className="flex flex-col gap-2">
                {examples.map((ex, i) => (
                  <button
                    key={i}
                    onClick={() => setInputText(ex.text)}
                    className="text-left text-[11px] font-mono text-slate-400 hover:text-white hover:bg-slate-800/50 p-2 border border-slate-800 transition-all truncate"
                  >
                    {">"} {ex.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right: Analysis Dashboard */}
        <div className="md:col-span-8 flex flex-col gap-6">
          <AnimatePresence mode="wait">
            {!result && !error && !isAnalyzing && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                className="flex-1 border border-dashed border-slate-800 flex flex-col items-center justify-center p-12 text-center"
              >
                <div className="w-16 h-16 bg-slate-900 border border-slate-800 rounded-full flex items-center justify-center mb-4">
                  <Shield className="w-8 h-8 text-slate-700" />
                </div>
                <h3 className="text-xl font-bold text-slate-500 uppercase tracking-widest">Waiting for input</h3>
                <p className="text-slate-600 text-sm mt-2 max-w-xs">Analysis results will be displayed here after content is processed.</p>
              </motion.div>
            )}

            {isAnalyzing && (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                className="flex-1 border border-slate-800 bg-slate-900/10 flex flex-col items-center justify-center p-12 overflow-hidden"
              >
                <motion.div
                  animate={{ 
                    scale: [1, 1.1, 1],
                    opacity: [0.3, 1, 0.3]
                  }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-24 h-24 border-t-2 border-red-500 rounded-full animate-spin mb-6"
                />
                <p className="text-red-500 font-mono text-sm tracking-widest animate-pulse">EXTRACTING PATTERNS...</p>
              </motion.div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex-1 bg-red-950/20 border border-red-900/50 p-8 flex flex-col items-center justify-center text-center space-y-4"
              >
                <AlertCircle className="w-12 h-12 text-red-500" />
                <div>
                  <h3 className="text-red-500 font-bold uppercase tracking-widest">System Error</h3>
                  <p className="text-red-400/70 text-sm font-mono mt-1">{error}</p>
                </div>
                <button onClick={handleAnalyze} className="btn-geo btn-geo-primary">Re-initialize</button>
              </motion.div>
            )}

            {result && !isAnalyzing && (
              <motion.div
                key="result"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex-1 flex flex-col gap-6"
              >
                {/* Visual Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className={`p-4 border ${
                    result.verdict === Verdict.SCAM ? "bg-red-500/10 border-red-500/30" :
                    result.verdict === Verdict.SUSPICIOUS ? "bg-amber-500/10 border-amber-500/30" :
                    "bg-emerald-500/10 border-emerald-500/30"
                  }`}>
                    <p className={`label-tech mb-1 ${
                      result.verdict === Verdict.SCAM ? "text-red-400" :
                      result.verdict === Verdict.SUSPICIOUS ? "text-amber-400" :
                      "text-emerald-400"
                    }`}>Verdict</p>
                    <p className={`text-2xl font-black ${
                      result.verdict === Verdict.SCAM ? "text-red-500" :
                      result.verdict === Verdict.SUSPICIOUS ? "text-amber-500" :
                      "text-emerald-500"
                    }`}>{result.verdict.toUpperCase()}</p>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 p-4">
                    <p className="label-tech mb-1">Scam Score</p>
                    <div className="flex items-end gap-1">
                      <p className={`text-2xl font-black ${
                        result.scamScore > 70 ? "text-red-500" :
                        result.scamScore > 30 ? "text-amber-500" :
                        "text-emerald-500"
                      }`}>{result.scamScore}</p>
                      <p className="text-[10px] text-slate-500 font-mono pb-1">/100</p>
                    </div>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 p-4">
                    <p className="label-tech mb-1">Risk Level</p>
                    <p className={`text-2xl font-black ${
                      result.riskLevel === "High" ? "text-red-500" :
                      result.riskLevel === "Medium" ? "text-amber-500" :
                      "text-emerald-500"
                    }`}>{result.riskLevel.toUpperCase()}</p>
                  </div>
                  <div className="bg-slate-900 border border-slate-800 p-4">
                    <p className="label-tech mb-1">Scam Type</p>
                    <p className="text-2xl font-black text-white italic underline underline-offset-4 decoration-red-500 truncate">
                      {result.type.toUpperCase()}
                    </p>
                  </div>
                </div>

                {/* Highlighted Words */}
                {result.highlightedWords.length > 0 && (
                  <div className="space-y-2">
                    <p className="label-tech opacity-50">Suspicious Phrases</p>
                    <div className="flex flex-wrap gap-2">
                      {result.highlightedWords.map((word, i) => (
                        <span key={i} className="px-2 py-1 bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono rounded">
                          {word}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Details Grid */}
                <div className="grid md:grid-cols-2 gap-4 flex-1">
                  <div className="bg-slate-900/50 border border-slate-800 p-6 flex flex-col">
                    <h3 className="text-xs uppercase tracking-widest text-slate-400 font-bold mb-4 flex items-center gap-2">
                      <span className="w-2 h-2 bg-slate-400 rounded-full"></span> Reason
                    </h3>
                    <p className="text-sm text-slate-300 leading-relaxed font-mono">
                      {result.reason}
                    </p>
                  </div>
                  <div className="bg-slate-900/50 border border-slate-800 p-6 flex flex-col">
                    <h3 className="text-xs uppercase tracking-widest text-red-400 font-bold mb-4 flex items-center gap-2">
                      <span className="w-2 h-2 bg-red-400 rounded-full"></span> Threat Indicators
                    </h3>
                    <ul className="space-y-3">
                      {result.redFlags.map((flag, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <span className="text-red-500 font-bold font-mono">!</span>
                          <span className="text-sm text-slate-300 font-mono tracking-tight">{flag}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Advice Panel */}
                <div className="bg-red-600/10 border-l-4 border-red-600 p-6">
                  <h4 className="text-xs uppercase tracking-[0.2em] font-black text-red-500 mb-2">Protocol Suggestion</h4>
                  <p className="text-slate-200 text-sm mb-6 leading-relaxed">
                    {result.advice}
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <button className="btn-geo btn-geo-primary">Isolate Context</button>
                    <button className="btn-geo">Report Hash</button>
                    <button className="btn-geo">Mark Safe</button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer Branding */}
      <footer className="mt-8 pt-6 border-t border-slate-900 flex flex-col sm:flex-row justify-between items-center gap-4">
        <p className="text-[10px] text-slate-600 uppercase tracking-[0.3em] font-medium">
          Guardia Systems AI-Driven Security & Analysis Protocol • 2026
        </p>
        <div className="flex gap-4">
           <div className="w-2 h-2 bg-slate-800 rounded-full animate-pulse"></div>
           <div className={`w-2 h-2 rounded-full ${isAnalyzing ? "bg-amber-800 animate-bounce" : "bg-slate-800"}`}></div>
           <div className="w-2 h-2 bg-slate-800 rounded-full"></div>
        </div>
      </footer>
    </div>
  );
}
