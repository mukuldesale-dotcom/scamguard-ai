/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, Verdict, RiskLevel } from "./types";

const ai = new GoogleGenAI({ 
  apiKey: process.env.GEMINI_API_KEY || "" 
});

const SYSTEM_INSTRUCTION = `You are an advanced AI Scam Detection Assistant specialized in identifying fraud, phishing, and suspicious messages, especially in India.
Analyze the provided message text and determine its status.

Guidelines:
- Categorize the text as Safe, Suspicious, or Scam.
- Provide a Scam Score from 0 to 100 (0 = Safe, 100 = Definitive Scam).
- Assign a Risk Level: Low, Medium, or High.
- Identify the Type of Scam (e.g., UPI scam, OTP fraud, job scam, phishing, electricity bill scam, KYC update scam).
- Highlight specific suspicious words or phrases from the input text.
- Provide a simple, beginner-friendly explanation of why it was categorized this way, focusing on real-world scam patterns in India.
- List specific "Red Flags" in bullet points (suspicious keywords, urgency, link patterns, odd numbers).
- Provide clear, practical advice on what the user should do next.
- If it's Safe, clarify that while it seems safe, users should always remain cautious.

IMPORTANT: Your response must strictly follow the JSON schema provided.`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    verdict: {
      type: Type.STRING,
      enum: ["Safe", "Suspicious", "Scam"],
      description: "The safety categorization of the input text.",
    },
    scamScore: {
      type: Type.NUMBER,
      description: "A score from 0 to 100 indicating the probability of a scam.",
    },
    riskLevel: {
      type: Type.STRING,
      enum: ["Low", "Medium", "High"],
      description: "The estimated risk level.",
    },
    type: {
      type: Type.STRING,
      description: "The specific type of scam identified, or 'None' if Safe.",
    },
    highlightedWords: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of specific suspicious words or phrases from the input.",
    },
    reason: {
      type: Type.STRING,
      description: "A simple explanation of the reasoning.",
    },
    redFlags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "A list of specific suspicious elements found.",
    },
    advice: {
      type: Type.STRING,
      description: "Practical advice for the user.",
    },
  },
  required: ["verdict", "scamScore", "riskLevel", "type", "highlightedWords", "reason", "redFlags", "advice"],
};

export async function analyzeText(text: string): Promise<AnalysisResult> {
  if (!text.trim()) {
    throw new Error("Input text cannot be empty.");
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        {
          role: "user",
          parts: [{ text: `Analyze this text for scams, considering Indian contexts:\n\n"${text}"` }],
        },
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
        temperature: 0.2,
      },
    });

    const result = JSON.parse(response.text || "{}");
    
    return {
      verdict: result.verdict as Verdict,
      scamScore: result.scamScore || 0,
      riskLevel: result.riskLevel as RiskLevel,
      type: result.type || "N/A",
      highlightedWords: result.highlightedWords || [],
      reason: result.reason || "Unable to determine reason.",
      redFlags: result.redFlags || [],
      advice: result.advice || "Stay vigilant and avoid clicking suspicious links.",
    };
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw new Error("Failed to analyze the text. Please try again later.");
  }
}
